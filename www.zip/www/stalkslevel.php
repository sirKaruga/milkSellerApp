<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <script src="lib/chart-master/Chart.js"></script>

  <link href="Preloader-master/preloader.css" rel="stylesheet">
  <!-- =======================================================
    Application Name: Stocks Manager
    Developed by: sirKaruga
    Author: Ruth Maina

  ======================================================= -->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>STOCKS<span>MANAGER</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
          
        </ul>
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="index.php">Refresh</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="owner2.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered">Mr. Maina</h5>
          <li class="mt">
            <a href="index.php">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
          <li class="sub-menu">
            <a class="active" href="javascript:;">
              <i class="fa fa-desktop"></i>
              <span>Elements</span>
              </a>
            <ul class="sub">
              <li class="active"><a  href="stalkslevel.php">Stock Level</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-cogs"></i>
              <span>Components</span>
              </a>
            <ul class="sub">
              <li><a href="register.html">Register new Product</a></li>
              <li><a href="updateprices.php">Update Prices</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Extras</span>
              </a>
            <ul class="sub">
              <li><a href="register.html">Register new Product</a></li>
              <li><a href="allsales.php">All Sales</a></li>
              <li><a href="invoice.php">All Purchases</a></li>
              <li><a href="pricing_table.php">Products & prices</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Recordings</span>
              </a>
            <ul class="sub">
              <li><a href="form_component.php">Record Day Sales</a></li>
              <li><a href="purchase_register.php">Record Purchases</a></li>
              <li><a href="deleterecord.php">Delete a sale Record</a></li>
              <li><a href="deletepurchase.php">Delete a Purchase Record</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-th"></i>
              <span>Data Tables</span>
              </a>
            <ul class="sub">
              <li><a href="allsales.php">All Sales</a></li>
              <li><a href="invoice.php">All Purchases</a></li>
            </ul>
          </li>
          

        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <?php
echo "<h1>Remaining Stock</h1>";
  class MyDB extends SQLite3{
    function __construct()
    {
      $this->open('manager.db');
    }
  }

  $db = new MyDB();
  $sql2= "SELECT * FROM prod_calibrations";
  $result = $db ->query($sql2);
  $myArray = array();
  $results = $db->query('SELECT COUNT(*) FROM (SELECT `id`,* FROM `prod_calibrations` ORDER BY `id` ASC);');
        while ($row = $results->fetchArray()) {
           $limit= $row["COUNT(*)"];
        }

  while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
   
  array_push($myArray, "
    <tr>
    <td>".$row['id']."</td>
    <td>".$row['product']."</td>
    <td>".$row['ml_100']."</td>
    <td>".$row['ml_150']."</td>
    <td>".$row['ml_200']."</td>
    <td>".$row['ml_250']."</td>
    <td>".$row['ml_500']."</td>
  </tr>");
  }
  echo "<table class='table table-hover table-striped'>
  <thead>
    <tr>
      <th>S/No.</th>
      <th>Name</th>
      <th>100ml(pkts)</th>
      <th>150ml(pkts)</th>
      <th>200ml(pkts)</th>
      <th>250ml(pkts)</th>
      <th>500ml(pkts)</th>
    </tr>
  </thead>";
  //echo print_r($myArray);
  for ($i=0; $i < $limit; $i++) { 
    echo $myArray[$i];
  }
  

  echo "</table>";
?>

      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>Stocks Manager</strong>. All Rights Reserved
        </p>
        <div class="credits">
          
          Created by sirKaruga && MainaRuth
        </div>
        <a href="index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>

  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="lib/jquery.scrollTo.min.js"></script>
  <script src="lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="lib/common-scripts.js"></script>
  <!--script for this page-->
  <script type="text/javascript" src="lib/gritter/js/jquery.gritter.js"></script>
  <script type="text/javascript" src="lib/gritter-conf.js"></script>
</body>

</html>
