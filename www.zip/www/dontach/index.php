<?php
	/**
	 * 
	 */
	class MyDB extends SQLite3{
		function __construct()
		{
			$this->open('manager.db');
		}
	}
	$db = new MyDB();

	$sql ="INSERT INTO meuser(name, name2, location)VALUES('john', 'Muita', 'Nairobi');";
	$db->query($sql);

	echo "executed";

	$sql2= "SELECT * FROM meuser";
	$result = $db ->query($sql2);

	while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
		echo $row['id']."<br>";
		echo $row['name']."<br>";
		echo $row['name2']."<br>";
		echo $row['location']."<hr>";
	}

	$results = $db->query('SELECT COUNT(*) FROM (SELECT `id`,* FROM `aproducts` ORDER BY `id` ASC);');
        while ($row = $results->fetchArray()) {
           $limit= $row["COUNT(*)"];
        }
?>