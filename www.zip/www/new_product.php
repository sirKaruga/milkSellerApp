<?php
	class MyDB extends SQLite3{
		function __construct()
		{
			$this->open('manager.db');
		}
	}

	$db = new MyDB();

	$pname =$_POST['pname'];
	$bp_100 =preg_replace('~\D~', '', $_POST['bp_100']);
	$sp_100 =preg_replace('~\D~', '', $_POST['sp_100']);
	$bp_150 =preg_replace('~\D~', '', $_POST['bp_150']);
	$sp_150 =preg_replace('~\D~', '', $_POST['sp_150']);
	$bp_200 =preg_replace('~\D~', '', $_POST['bp_200']);
	$sp_200 =preg_replace('~\D~', '', $_POST['sp_200']);
	$bp_250 =preg_replace('~\D~', '', $_POST['bp_250']);
	$sp_250 =preg_replace('~\D~', '', $_POST['sp_250']);
	$bp_500 =preg_replace('~\D~', '', $_POST['bp_500']);
	$sp_500 =preg_replace('~\D~', '', $_POST['sp_500']);

	$result = $db->query("SELECT * FROM aproducts WHERE pname = '$pname'");
	$row=$result->fetchArray(SQLITE3_ASSOC);
    // check for empty result
    if ($row != false) {
      // do something here if record exists
    	echo "A product with that name already exists";
    	?><br><a href="index.php"><button>Back Home</button></a><?php
    }else{
    	
    	$sql ="INSERT INTO aproducts(pname, bp_100, sp_100, bp_150, sp_150, bp_200, sp_200, bp_250, sp_250, bp_500, sp_500)VALUES('$pname', '$bp_100', '$sp_100', '$bp_150', '$sp_150', '$bp_200', '$sp_200', '$bp_250', '$sp_250', '$bp_500', '$sp_500');";
		$db->query($sql);

		$calibrator = "INSERT INTO prod_calibrations(product, ml_100, ml_150, ml_200, ml_250, ml_500)VALUES('$pname', '0', '0', '0', '0', '0')";
		$db->query($calibrator);

		header("location:index.php");
    }
?>