<?php
 class MyDB extends SQLite3{
    function __construct()
    {
      $this->open('manager.db');
    }
  }
$db = new MyDB();
$mid= $_GET['id'];
// get values of record to delete
  $sql2= "SELECT * FROM purchases WHERE id='$mid'";
  $result = $db ->query($sql2);
 while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    $ml_100 =$row['ml_100'];
    $ml_150 =$row['ml_150'];
    $ml_200= $row['ml_200'];
    $ml_250= $row['ml_250'];
    $ml_500= $row['ml_500'];
    $product = $row['product'];
  }
$sql3= "SELECT * FROM prod_calibrations WHERE product='$product'";
  $result2 = $db ->query($sql3);
 while ($row = $result2->fetchArray(SQLITE3_ASSOC)) {
    $cml_100 =$row['ml_100'];
    $cml_150 =$row['ml_150'];
    $cml_200= $row['ml_200'];
    $cml_250= $row['ml_250'];
    $cml_500= $row['ml_500'];
  }

$new_ml_100 = $cml_100 - $ml_100;
$new_ml_150 = $cml_150 - $ml_150;
$new_ml_200 = $cml_200 - $ml_200;
$new_ml_250 = $cml_250 - $ml_250;
$new_ml_500 = $cml_500 - $ml_500;

$prod_ml_100= "UPDATE prod_calibrations
SET 
    ml_100='$new_ml_100',
    ml_150='$new_ml_150',
    ml_200='$new_ml_200',
    ml_250='$new_ml_250',
    ml_500='$new_ml_500'
WHERE
    product='$product'";
$db->query($prod_ml_100);

$query = "DELETE FROM purchases
WHERE id='$mid'";
$db ->query($query);
//echo "<script>location:deleterecord.php;</script>";
header('location:index.php');
?>