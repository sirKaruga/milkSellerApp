<?php
header('Content-Type: application/json');

class MyDB extends SQLite3{
		function __construct()
		{
			$this->open('manager.db');
		}
	}
	$conn = new MyDB();

	$sql ="SELECT id,date,t_sales FROM comprehensive_sales ORDER BY id";
	$result = $conn->query($sql);

	$data = array();
foreach ($result as $row) {
	$data[] = $row;
}

mysqli_close($conn);

echo json_encode($data);
?>