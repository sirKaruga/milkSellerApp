<?php
 class MyDB extends SQLite3{
    function __construct()
    {
      $this->open('manager.db');
    }
  }
$db = new MyDB();
$mid= $_GET['id'];
// get values of record to delete

 $sql2= "SELECT * FROM aproducts WHERE id='$mid'";
  $result = $db ->query($sql2);
 while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    $name_id =$row['pname'];
    
  }

$deleteR_product_calibrations="DELETE FROM prod_calibrations WHERE product='$name_id'";
  $db->query($deleteR_product_calibrations);

$deleteR_aproducts="DELETE FROM aproducts WHERE id='$mid'";
  $db->query($deleteR_aproducts);
// echo "<script>location:deleteproduct.php;</script>";
header('location:deleteproduct.php');
?>