<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <script src="lib/chart-master/Chart.js"></script>

  <link href="Preloader-master/preloader.css" rel="stylesheet">
  <!-- =======================================================
    Application Name: Stocks Manager
    Developed by: sirKaruga
    Author: Ruth Maina

  ======================================================= -->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>STOCKS<span>MANAGER</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
          
        </ul>
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="index.php">Refresh</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="owner2.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered">Mr. Maina</h5>
          <li class="mt">
            <a href="index.php">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-desktop"></i>
              <span>Elements</span>
              </a>
            <ul class="sub">
              <li><a href="stalkslevel.php">Stock Level</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a class="active" href="javascript:;">
              <i class="fa fa-cogs"></i>
              <span>Components</span>
              </a>
            <ul class="sub">
              <li><a href="register.html">Register new Product</a></li>
              <li><a class="active" href="updateprices.php">Update Prices</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Extras</span>
              </a>
            <ul class="sub">
              <li><a href="register.html">Register new Product</a></li>
              <li><a href="allsales.php">All Sales</a></li>
              <li><a href="invoice.php">All Purchases</a></li>
              <li><a href="pricing_table.php">Products & prices</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Recordings</span>
              </a>
            <ul class="sub">
              <li><a href="form_component.php">Record Day Sales</a></li>
              <li><a href="purchase_register.php">Record Purchases</a></li>
              <li><a href="deleterecord.php">Delete a sale Record</a></li>
              <li><a href="deletepurchase.php">Delete a Purchase Record</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-th"></i>
              <span>Data Tables</span>
              </a>
            <ul class="sub">
              <li><a href="allsales.php">All Sales</a></li>
              <li><a href="invoice.php">All Purchases</a></li>
            </ul>
          </li>
          

        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        
<?php
 class MyDB extends SQLite3{
    function __construct()
    {
      $this->open('manager.db');
    }
  }
$db = new MyDB();
$mid= $_GET['id'];
// get values of record to delete
  $sql2= "SELECT * FROM aproducts WHERE id='$mid'";
  $result = $db ->query($sql2);
 while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    $product = $row['pname'];
    $bp_100 =$row['bp_100'];
    $bp_150 =$row['bp_150'];
    $bp_200= $row['bp_200'];
    $bp_250= $row['bp_250'];
    $bp_500= $row['bp_500'];
    $sp_100 =$row['sp_100'];
    $sp_150 =$row['sp_150'];
    $sp_200= $row['sp_200'];
    $sp_250= $row['sp_250'];
    $sp_500= $row['sp_500'];
    
  }

?>
<h2>Register Product</h2>
              
              <form class="form-inline" method="post">
                <div class="form-group">
                  <label for="name">Prod_name:</label>
                  <?php echo "<b style 'font-size:2em; color: black;'>$product</b>"; ?>
                </div>

                <div class="centered">
                <div class="form-group">
                  <label for="price">100ml Buying_Price:</label>
                  <input type="price" class="form-control" placeholder="B.Price in Ksh." name="bp_100" value="<?php echo($bp_100); ?>" >
                </div>
                <div class="form-group">
                  <label for="price">100ml Selling_Price:</label>
                  <input type="price" class="form-control" placeholder="S.Price in Ksh." name="sp_100" value="<?php echo($sp_100); ?>">
                </div></br>
                <div class="form-group">
                  <label for="price">150ml Buying_Price:</label>
                  <input type="price" class="form-control" placeholder="B.Price in Ksh." name="bp_150" value="<?php echo($bp_150); ?>">
                </div>
                <div class="form-group">
                  <label for="price">150ml Selling_Price:</label>
                  <input type="price" class="form-control" placeholder="S.Price in Ksh." name="sp_150" value="<?php echo($sp_150); ?>">
                </div><br>
                <div class="form-group">
                  <label for="price">200ml Buying_Price:</label>
                  <input type="price" class="form-control" placeholder="B.Price in Ksh." name="bp_200"value="<?php echo($bp_200); ?>">
                </div>
                <div class="form-group">
                  <label for="price">200ml Selling_Price:</label>
                  <input type="price" class="form-control" placeholder="S.Price in Ksh." name="sp_200" value="<?php echo($sp_200); ?>">
                </div><br>
                <div class="form-group">
                  <label for="price">250ml Buying_Price:</label>
                  <input type="price" class="form-control" placeholder="B.Price in Ksh." name="bp_250" value="<?php echo($bp_250); ?>">
                </div>
                <div class="form-group">
                  <label for="price">250ml Selling_Price:</label>
                  <input type="price" class="form-control" placeholder="S.Price in Ksh." name="sp_250" value="<?php echo($sp_250); ?>">
                </div><br>
                <div class="form-group">
                  <label for="price">500ml Buying_Price:</label>
                  <input type="price" class="form-control" placeholder="B.Price in Ksh." name="bp_500" value="<?php echo($bp_500); ?>">
                </div>
                <div class="form-group">
                  <label for="price">500ml Selling_Price:</label>
                  <input type="price" class="form-control" placeholder="S.Price in Ksh." name="sp_500" value="<?php echo($sp_500); ?>">
                </div><br><br>

                <button type="submit" class="btn btn-default" name="Submit">Update</button>
                </div>
                
              </form>

 <?php
 if(isset($_POST["Submit"])){
  $bp_100 =preg_replace('~\D~', '', $_POST['bp_100']);
  $sp_100 =preg_replace('~\D~', '', $_POST['sp_100']);
  $bp_150 =preg_replace('~\D~', '', $_POST['bp_150']);
  $sp_150 =preg_replace('~\D~', '', $_POST['sp_150']);
  $bp_200 =preg_replace('~\D~', '', $_POST['bp_200']);
  $sp_200 =preg_replace('~\D~', '', $_POST['sp_200']);
  $bp_250 =preg_replace('~\D~', '', $_POST['bp_250']);
  $sp_250 =preg_replace('~\D~', '', $_POST['sp_250']);
  $bp_500 =preg_replace('~\D~', '', $_POST['bp_500']);
  $sp_500 =preg_replace('~\D~', '', $_POST['sp_500']);

$new_pdate= "UPDATE aproducts
SET 
    bp_100='$bp_100',
    sp_100='$sp_100',
    bp_150='$bp_150',
    sp_150='$sp_150',
    bp_200='$bp_200',
    sp_200='$sp_200',
    bp_250='$bp_250',
    sp_250='$sp_250',
    bp_500='$bp_500',
    sp_500='$sp_500'
WHERE
    id='$mid'";
$db->query($new_pdate);
}

 
  ?>

            <!-- ******************************************* -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>Stocks Manager</strong>. All Rights Reserved
        </p>
        <div class="credits">
          
          Created by sirKaruga && MainaRuth
        </div>
        <a href="index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="lib/jquery.scrollTo.min.js"></script>
  <script src="lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="lib/common-scripts.js"></script>
  <!--script for this page-->

</body>

</html>
